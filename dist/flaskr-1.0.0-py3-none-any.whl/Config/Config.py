

class Config:
    def __init__(self):
        self.JWT_SECRET = 'supaSecret'
        self.MAIL_SERVER = 'mail25.mydevil.net'
        self.MAIL_PORT = 993
        self.MAIL_USERNAME = 'tackgnol@tackgnol.usermd.net'
        self.MAIL_PASSWORD = '742617Gus'
        self.MONGO_USERNAME = 'mo1002_VirtualCV'
        self.MONGO_PASSWORD = '742617Gus'
        self.MONGO_HOST = 'mongo25.mydevil.net'
        self.MONGO_DB = 'mo1002_VirtualCV'
